# NodeJS with JSON
 
### Create a Local Host Server using Express JS and Perform the following operations
 
- Store Your JSON file in Local Host (Implement FS module in order to read the JSON file)
- Perform read and write operation on JSON in the server side
- Implement Routing feature using NodeJS
- Manipulate the server response in the client side
